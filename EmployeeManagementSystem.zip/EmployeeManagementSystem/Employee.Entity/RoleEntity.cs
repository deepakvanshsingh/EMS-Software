﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Employee.Entity
{
    /**********Role class entities******/
    [Serializable]
    public class RoleEntity : EmployeeEntity
    {
        public int roleId { get; set; }
        public string roleName { get; set; }
        public string roleDescription { get; set; }
    }
}
