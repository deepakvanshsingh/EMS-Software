﻿using System;

namespace Employee.Entity
{
    [Serializable]
    /****************employee entity attribute***************/
    public class EmployeeEntity
    {

        public string employeeName { get; set; }
        public int employeeId { get; set; }
        public string employeeKinId { get; set; }
        public string employeeEmailId { get; set; }
        public long employeePhoneNumber { get; set; }
        public string employeeAddress { get; set; }
        public string employeeDateOfBirth { get; set; }
        public string employeeDateOfJoining { get; set; }
        public int employeeDepartmentId { get; set; }
        public int employeeProjectId { get; set; }
        public int employeeRoleId { get; set; }
    }
}
