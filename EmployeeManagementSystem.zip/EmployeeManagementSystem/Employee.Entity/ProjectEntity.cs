﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Employee.Entity
{
    /**********Project class entities******/
    [Serializable]
    public class ProjectEntity : EmployeeEntity
    {
        public int projectId { get; set; }
        public string projectName { get; set; }
        public string projectDescription { get; set; }
    }
}
